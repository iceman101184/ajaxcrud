<?php
/*
    class DB_Connect {
        private $conn;

        // Connecting to database
        public function connect() {

            // Connecting to mysql database
            // $this->conn = new mysqli('localhost', 'username', 'password', 'database name');
            $this->conn = new mysqli('localhost', 'root', '', 'misc_data');
                // return database handler
                return $this->conn;
        }   
    }

$myconn = new DB_Connect();
$myconn->connect();
$link = $myconn->conn;
*/

// header('Content-Type: text/plain; charset=utf-8');

$brlf = "<br>\n";
$link = new mysqli("localhost","root","","misc_data");
$link->set_charset("utf8");

// Check connection
if ($link->connect_errno) {
  echo "Failed to connect to MySQL: " . $link-> connect_error . $brlf;
  exit();
}

function q($sql) {
	global $link;
	// Perform query
	if ($result = $link->query($sql)) {
	//  echo "Returned rows are: " . $result->num_rows . $brlf;
	  return $result;
	  // Free result set
	  // $result -> free_result();
	}
}

$tnlist = "SELECT District, CONVERT(DistrictLL USING utf8) as DistrictLocalLang FROM districts WHERE `State` = 'TAMIL NADU' ORDER BY District";

$res = q($tnlist);
// echo "Returned rows are: " . $res->num_rows . $brlf;
$rows = Array();
while($rows[] = $res->fetch_array(MYSQLI_ASSOC));

// echo print_r($rows, true);

$html = "<html><head><title>Districts in Tamilnadu, India</title><meta charset=\"utf-8\"></head><body><table border=1>\n"."<tr><th>District</th><th>DistrictLL</th></tr>\n";
foreach ($rows as $k => $v) {
	if($v['District'] <> '')
		$html .= "<tr><td>".ucwords(strtolower(($v['District'])))."</td><td>$v[DistrictLocalLang]</td></tr>\n";
}
$html .= "</table></body></html>";

echo $html;
?>